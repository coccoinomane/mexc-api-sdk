import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

__jsii_assembly__ = jsii.JSIIAssembly.load(
    "mexc-sdk", "1.0.0", __name__[0:-6], "mexc-sdk@1.0.0.jsii.tgz"
)

__all__ = [
    "__jsii_assembly__",
]

publication.publish()
